package com.domie.poolassistant

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
            setBackgroundColor(Color.rgb(7, 19, 32))
        }
        val title = TextView(this).apply {
            text = "🎱 AI Pool Assistant"
            textSize = 26f
            setTextColor(Color.WHITE)
        }
        val description = TextView(this).apply {
            text = "Prototype 0.1\\n\\nThis first native build displays a movable floating aiming guide. It does not yet read your game screen or calculate real ball physics."
            textSize = 16f
            setTextColor(Color.LTGRAY)
            setPadding(0, 20, 0, 24)
        }
        val start = Button(this).apply {
            text = "Enable floating overlay"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName"))
                    startActivity(intent)
                } else {
                    startService(Intent(this@MainActivity, OverlayService::class.java))
                    finish()
                }
            }
        }
        val note = TextView(this).apply {
            text = "After granting permission, return here and tap the button again."
            textSize = 13f
            setTextColor(Color.rgb(150, 190, 210))
            setPadding(0, 18, 0, 0)
        }
        layout.addView(title)
        layout.addView(description)
        layout.addView(start, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        layout.addView(note)
        setContentView(layout)
    }
}

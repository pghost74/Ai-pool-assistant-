package com.domie.poolassistant

import android.app.Service
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PathEffect
import android.graphics.DashPathEffect
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import kotlin.math.cos
import kotlin.math.sin

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var overlay: FrameLayout? = null
    private var angle = 30f
    private var visible = true

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (overlay != null) return START_NOT_STICKY
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val root = FrameLayout(this)
        val guide = GuideView()
        root.addView(guide, FrameLayout.LayoutParams(300, 240))
        val controls = FrameLayout(this)
        val minus = TextView(this).apply {
            text = " − "
            textSize = 24f; setTextColor(Color.WHITE); setBackgroundColor(0xCC102A40.toInt())
            setOnClickListener { angle = (angle - 5f).coerceIn(-80f, 80f); guide.invalidate() }
        }
        val plus = TextView(this).apply {
            text = " + "
            textSize = 24f; setTextColor(Color.WHITE); setBackgroundColor(0xCC102A40.toInt())
            setOnClickListener { angle = (angle + 5f).coerceIn(-80f, 80f); guide.invalidate() }
        }
        val close = TextView(this).apply {
            text = " × "
            textSize = 24f; setTextColor(Color.WHITE); setBackgroundColor(0xCC602030.toInt())
            setOnClickListener { stopSelf() }
        }
        val lp = FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END)
        root.addView(minus, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START))
        root.addView(plus, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        root.addView(close, lp)
        root.setOnTouchListener(object : View.OnTouchListener {
            var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                val params = overlay?.layoutParams as? WindowManager.LayoutParams ?: return false
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { downX=e.rawX; downY=e.rawY; startX=params.x; startY=params.y; return true }
                    MotionEvent.ACTION_MOVE -> { params.x=startX+(e.rawX-downX).toInt(); params.y=startY+(e.rawY-downY).toInt(); wm.updateViewLayout(root,params); return true }
                }
                return false
            }
        })
        val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        val params = WindowManager.LayoutParams(300, 240, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = 50; y = 180 }
        overlay = root
        wm.addView(root, params)
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        overlay?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        overlay = null
        super.onDestroy()
    }

    inner class GuideView : View(this@OverlayService) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            canvas.drawColor(Color.TRANSPARENT)
            p.color = 0xCC061725.toInt(); p.style = Paint.Style.FILL
            canvas.drawRoundRect(4f, 4f, width-4f, height-4f, 18f, 18f, p)
            val cx = width * .25f
            val cy = height * .72f
            p.color = Color.WHITE; p.style = Paint.Style.FILL
            canvas.drawCircle(cx, cy, 9f, p)
            val radians = Math.toRadians(angle.toDouble())
            val ex = cx + cos(radians).toFloat() * width * .62f
            val ey = cy - sin(radians).toFloat() * height * .62f
            p.color = 0xFF23F29A.toInt(); p.strokeWidth = 3.5f; p.style = Paint.Style.STROKE; p.pathEffect = null
            canvas.drawLine(cx, cy, ex, ey, p)
            p.color = 0xFF20C8FF.toInt(); p.strokeWidth = 3f
            p.pathEffect = DashPathEffect(floatArrayOf(9f, 8f), 0f)
            canvas.drawLine(ex, ey, ex + 28f, ey - 20f, p)
            p.pathEffect = null
            p.color = Color.WHITE; p.textSize = 15f; p.style = Paint.Style.FILL
            canvas.drawText("AIM ${angle.toInt()}°", 14f, height-13f, p)
        }
    }
}
